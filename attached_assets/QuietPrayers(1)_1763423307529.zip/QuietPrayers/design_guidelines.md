# Design Guidelines: Quiet Prayers

## Design Approach
**Reference-Based Approach** drawing inspiration from meditation and spiritual applications (Calm, Headspace) combined with respectful community platforms. The design must convey peace, safety, and reverence while facilitating meaningful connection through shared prayer.

## Core Design Principles
1. **Serenity First**: Every element should contribute to a calm, focused atmosphere
2. **Respectful Distance**: Anonymous sharing without intrusive social features
3. **Clarity & Accessibility**: Prayers must be highly readable and easy to navigate
4. **Trust Signals**: Visible moderation and community standards

## Typography System
- **Primary Font**: Google Fonts - "Inter" (clean, highly readable)
- **Accent Font**: "Crimson Pro" or "Lora" (serif, for prayer text to add warmth)
- **Hierarchy**:
  - H1: text-4xl font-semibold (page titles)
  - H2: text-2xl font-medium (section headers)
  - H3: text-xl font-medium (category names)
  - Prayer text: text-lg leading-relaxed (accent font for readability)
  - Body: text-base (UI elements, metadata)
  - Small: text-sm (timestamps, user IDs)

## Layout System
**Spacing Primitives**: Use Tailwind units of 3, 4, 6, 8, 12, 16 for consistent rhythm
- Component padding: p-6 to p-8
- Section spacing: py-12 to py-16
- Card gaps: gap-6
- Container max-width: max-w-4xl (focused, readable width)

## Component Library

### Navigation Header
- Sticky top navigation with subtle backdrop blur
- Logo/app name on left
- Search bar center (prominent, always visible)
- Category filter dropdown on right
- Height: h-16, padding: px-6

### Prayer Cards (Primary Component)
- Rounded corners: rounded-xl
- Padding: p-6
- Shadow: shadow-md with subtle hover lift (shadow-lg)
- Structure:
  - Prayer text (serif font, leading-relaxed)
  - Category badge (rounded-full px-3 py-1, subtle styling)
  - Footer row: Anonymous user ID (e.g., "User #7284") + timestamp
  - Approved indicator: small check icon with "Moderated" text
- Card spacing: space-y-6 between cards

### Category System
- Predefined categories displayed as filter chips
- Categories: Health, Family, Gratitude, Guidance, Peace, Strength, Forgiveness, Hope
- Active state: filled background
- Inactive state: outline style
- Horizontal scroll on mobile: flex overflow-x-auto

### Search & Filter Bar
- Prominent search input: h-12, rounded-lg
- Icon: magnifying glass (Heroicons)
- Placeholder: "Search prayers..."
- Category dropdown integrated alongside
- Real-time filtering (no submit button needed)

### Prayer Submission Form
- Modal overlay with centered card (max-w-2xl)
- Large textarea: min-h-48, rounded-lg, p-4
- Character counter: text-sm (e.g., "0/500")
- Category selector: radio buttons with visual category cards
- Submit button: Prominent, full-width on mobile
- Content guidelines displayed: small text with icon reminders

### Empty States
- Center-aligned with icon
- Encouraging message (e.g., "No prayers yet in this category")
- CTA to submit first prayer
- Generous padding: py-20

### Moderation Indicators
- Subtle "Verified" or "Approved" badge on each prayer
- Info tooltip: "This prayer has been reviewed to ensure it meets our community standards"
- Use shield or check icon (Heroicons)

## Layout Structure

### Main Prayer Feed
- Single column layout: max-w-4xl mx-auto
- Sticky category filter bar below header
- Infinite scroll or "Load More" pagination
- Prayer cards in vertical stack with consistent spacing

### Hero/Welcome Section (First Visit)
- Welcoming headline: "Share Your Prayers, Find Peace Together"
- Brief explanation of anonymous sharing and moderation
- CTA: "Share a Prayer" button (prominent)
- Background: Soft gradient or peaceful abstract pattern
- Height: 60vh on desktop, auto on mobile

### Category Browse View
- Grid layout on desktop: grid-cols-2 gap-6
- Each category as a clickable card showing:
  - Category name and icon
  - Prayer count
  - Recent prayer preview (truncated)

## Animations
**Minimal and purposeful only:**
- Card hover: subtle lift with shadow transition (200ms)
- Modal entry: fade + slide up (300ms)
- Toast notifications for submission success (slide in from top)
- Loading states: subtle pulse on skeleton cards

## Icons
**Library**: Heroicons (outline style for most, solid for active states)
- Search: MagnifyingGlassIcon
- Categories: specific icons per category (HeartIcon, HomeIcon, SparklesIcon, etc.)
- Moderation: ShieldCheckIcon
- User: UserCircleIcon
- Close/Cancel: XMarkIcon
- Submit: PaperAirplaneIcon

## Accessibility
- All form inputs with proper labels
- ARIA labels for icon buttons
- Keyboard navigation support for filters and cards
- Focus states: ring-2 ring-offset-2
- High contrast text ratios
- Skip to content link

## Mobile Considerations
- Single column layout throughout
- Bottom fixed "Share Prayer" FAB (floating action button)
- Horizontal scrolling category chips
- Full-screen modal for prayer submission
- Touch-friendly tap targets: min 44px height

## Images
**Hero Section**: Peaceful abstract imagery suggested - soft bokeh lights, gentle nature scenes, or calming gradients. Avoid literal religious imagery to remain inclusive. Image should be subtle background (opacity-40) with blurred backdrop for text overlay.

**No other images required** - the design relies on typography, spacing, and peaceful UI elements.