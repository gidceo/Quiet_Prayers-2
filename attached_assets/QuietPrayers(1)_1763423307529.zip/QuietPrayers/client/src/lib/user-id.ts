const USER_ID_KEY = 'quiet_prayers_user_id';

function generateUserId(): string {
  const randomNum = Math.floor(Math.random() * 9000) + 1000;
  return `User #${randomNum}`;
}

export function getUserId(): string {
  let userId = localStorage.getItem(USER_ID_KEY);
  
  if (!userId) {
    userId = generateUserId();
    localStorage.setItem(USER_ID_KEY, userId);
  }
  
  return userId;
}
