import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { PrayerCard } from "@/components/prayer-card";
import { PrayerFormDialog } from "@/components/prayer-form-dialog";
import { CategoryFilter } from "@/components/category-filter";
import { Search, Plus, Sparkles } from "lucide-react";
import type { Prayer } from "@shared/schema";

export default function Home() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const queryKey = selectedCategory
    ? [`/api/prayers?category=${encodeURIComponent(selectedCategory)}`]
    : ["/api/prayers"];

  const { data: prayers, isLoading } = useQuery<Prayer[]>({
    queryKey,
  });

  const filteredPrayers = prayers?.filter((prayer) => {
    const matchesSearch = searchQuery
      ? prayer.content.toLowerCase().includes(searchQuery.toLowerCase())
      : true;

    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-semibold" data-testid="text-app-title">
              Quiet Prayers
            </h1>
          </div>
          
          <Button 
            onClick={() => setIsDialogOpen(true)}
            size="sm"
            className="gap-2"
            data-testid="button-share-prayer"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Share Prayer</span>
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        <section className="text-center space-y-4 py-12">
          <h2 className="text-4xl font-semibold text-foreground">
            Share Your Prayers, Find Peace Together
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A peaceful space to share and discover prayers anonymously. 
            All prayers are reviewed to ensure a respectful and supportive community.
          </p>
          <Button
            onClick={() => setIsDialogOpen(true)}
            size="lg"
            className="mt-4"
            data-testid="button-share-prayer-hero"
          >
            <Plus className="w-5 h-5 mr-2" />
            Share a Prayer
          </Button>
        </section>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search prayers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 rounded-lg"
              data-testid="input-search"
            />
          </div>

          <CategoryFilter
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        <div className="space-y-6">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-48 w-full rounded-xl" />
            ))
          ) : filteredPrayers && filteredPrayers.length > 0 ? (
            filteredPrayers.map((prayer) => (
              <PrayerCard key={prayer.id} prayer={prayer} />
            ))
          ) : (
            <div className="text-center py-20 space-y-3">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
              <h3 className="text-xl font-medium text-foreground">
                {searchQuery || selectedCategory
                  ? "No prayers found"
                  : "No prayers yet"}
              </h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                {searchQuery || selectedCategory
                  ? "Try adjusting your search or category filter"
                  : "Be the first to share a prayer with the community"}
              </p>
              {!searchQuery && !selectedCategory && (
                <Button
                  onClick={() => setIsDialogOpen(true)}
                  variant="outline"
                  className="mt-4"
                  data-testid="button-share-first-prayer"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Share First Prayer
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      <PrayerFormDialog open={isDialogOpen} onOpenChange={setIsDialogOpen} />
    </div>
  );
}
