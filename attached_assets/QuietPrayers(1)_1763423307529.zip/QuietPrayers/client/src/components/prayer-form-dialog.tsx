import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { insertPrayerSchema, PRAYER_CATEGORIES, type InsertPrayer } from "@shared/schema";
import { getUserId } from "@/lib/user-id";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Heart, Home, Sparkles, Compass, Bird, Zap, HandHeart, Sun } from "lucide-react";

interface PrayerFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const categoryIcons = {
  Health: Heart,
  Family: Home,
  Gratitude: Sparkles,
  Guidance: Compass,
  Peace: Bird,
  Strength: Zap,
  Forgiveness: HandHeart,
  Hope: Sun,
};

export function PrayerFormDialog({ open, onOpenChange }: PrayerFormDialogProps) {
  const { toast } = useToast();
  const [charCount, setCharCount] = useState(0);
  
  const form = useForm<InsertPrayer>({
    resolver: zodResolver(insertPrayerSchema),
    defaultValues: {
      content: "",
      category: "Peace",
      userId: getUserId(),
    },
  });

  const createPrayerMutation = useMutation({
    mutationFn: async (data: InsertPrayer) => {
      return await apiRequest("POST", "/api/prayers", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prayers"] });
      toast({
        title: "Prayer Shared",
        description: "Your prayer has been shared with the community after moderation review.",
      });
      form.reset({
        content: "",
        category: "Peace",
        userId: getUserId(),
      });
      setCharCount(0);
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Unable to Share Prayer",
        description: error.message || "Your prayer could not be shared. Please ensure it follows our community guidelines.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertPrayer) => {
    createPrayerMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl" data-testid="dialog-prayer-form">
        <DialogHeader>
          <DialogTitle className="text-2xl font-semibold">Share a Prayer</DialogTitle>
          <DialogDescription>
            Your prayer will be shared anonymously after being reviewed to ensure it meets our community standards.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Prayer</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Share what's on your heart..."
                      className="min-h-48 resize-none text-base font-serif leading-relaxed"
                      onChange={(e) => {
                        field.onChange(e);
                        setCharCount(e.target.value.length);
                      }}
                      data-testid="input-prayer-content"
                    />
                  </FormControl>
                  <div className="flex items-center justify-between">
                    <FormMessage />
                    <span className="text-sm text-muted-foreground" data-testid="text-char-count">
                      {charCount}/500
                    </span>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl>
                    <RadioGroup
                      value={field.value}
                      onValueChange={field.onChange}
                      className="grid grid-cols-2 md:grid-cols-4 gap-3"
                    >
                      {PRAYER_CATEGORIES.map((category) => {
                        const Icon = categoryIcons[category];
                        return (
                          <FormItem key={category}>
                            <FormControl>
                              <RadioGroupItem
                                value={category}
                                id={category}
                                className="peer sr-only"
                                data-testid={`radio-category-${category.toLowerCase()}`}
                              />
                            </FormControl>
                            <FormLabel
                              htmlFor={category}
                              className="flex flex-col items-center justify-center gap-2 rounded-md border-2 border-muted bg-card p-4 hover-elevate cursor-pointer peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 transition-all"
                            >
                              <Icon className="w-6 h-6" />
                              <span className="text-sm font-medium">{category}</span>
                            </FormLabel>
                          </FormItem>
                        );
                      })}
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm text-muted-foreground">
                <ShieldCheck className="w-4 h-4 inline mr-1" />
                All prayers are reviewed to ensure they are respectful, supportive, and free from harmful content.
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createPrayerMutation.isPending}
                className="flex-1"
                data-testid="button-submit-prayer"
              >
                {createPrayerMutation.isPending ? "Sharing..." : "Share Prayer"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function ShieldCheck({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
      />
    </svg>
  );
}
