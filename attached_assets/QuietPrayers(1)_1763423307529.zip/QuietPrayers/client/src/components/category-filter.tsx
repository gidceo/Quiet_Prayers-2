import { Button } from "@/components/ui/button";
import { PRAYER_CATEGORIES } from "@shared/schema";
import { Heart, Home, Sparkles, Compass, Bird, Zap, HandHeart, Sun } from "lucide-react";

const categoryIcons = {
  Health: Heart,
  Family: Home,
  Gratitude: Sparkles,
  Guidance: Compass,
  Peace: Bird,
  Strength: Zap,
  Forgiveness: HandHeart,
  Hope: Sun,
};

interface CategoryFilterProps {
  selectedCategory: string | null;
  onCategoryChange: (category: string | null) => void;
}

export function CategoryFilter({ selectedCategory, onCategoryChange }: CategoryFilterProps) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
      <Button
        variant={selectedCategory === null ? "default" : "outline"}
        size="sm"
        onClick={() => onCategoryChange(null)}
        className="whitespace-nowrap"
        data-testid="button-category-all"
      >
        All Prayers
      </Button>
      {PRAYER_CATEGORIES.map((category) => {
        const Icon = categoryIcons[category];
        return (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => onCategoryChange(category)}
            className="whitespace-nowrap gap-2"
            data-testid={`button-category-${category.toLowerCase()}`}
          >
            <Icon className="w-4 h-4" />
            {category}
          </Button>
        );
      })}
    </div>
  );
}
