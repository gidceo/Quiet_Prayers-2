import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, User } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Prayer } from "@shared/schema";

interface PrayerCardProps {
  prayer: Prayer;
}

export function PrayerCard({ prayer }: PrayerCardProps) {
  return (
    <Card 
      className="p-6 transition-shadow duration-200 hover:shadow-lg" 
      data-testid={`card-prayer-${prayer.id}`}
    >
      <p 
        className="font-serif text-lg leading-relaxed text-card-foreground mb-4"
        data-testid="text-prayer-content"
      >
        {prayer.content}
      </p>
      
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Badge 
            variant="secondary" 
            className="rounded-full px-3 py-1"
            data-testid={`badge-category-${prayer.category.toLowerCase()}`}
          >
            {prayer.category}
          </Badge>
          
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <ShieldCheck className="w-4 h-4" />
            <span data-testid="text-moderated">Moderated</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1" data-testid="text-user-id">
            <User className="w-4 h-4" />
            <span>{prayer.userId}</span>
          </div>
          <span data-testid="text-timestamp">
            {formatDistanceToNow(new Date(prayer.createdAt), { addSuffix: true })}
          </span>
        </div>
      </div>
    </Card>
  );
}
