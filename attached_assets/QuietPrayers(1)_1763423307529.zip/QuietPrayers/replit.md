# Quiet Prayers

## Overview

Quiet Prayers is a web application for anonymous prayer sharing in a safe, moderated community. Users can submit prayers across various spiritual categories (Health, Family, Gratitude, Guidance, Peace, Strength, Forgiveness, Hope), which are reviewed through AI-powered content moderation before being displayed publicly. The application emphasizes serenity, respectful distance, and trust through its design inspired by meditation apps like Calm and Headspace.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript
- Vite as the build tool and development server
- Wouter for client-side routing
- TanStack Query (React Query) for server state management
- Shadcn UI component library with Radix UI primitives
- Tailwind CSS for styling

**Design System:**
- Typography: Inter (primary), Lora (serif for prayer content)
- Color scheme: Neutral-based palette with serenity-focused light mode
- Component library: Custom implementations of Shadcn components
- Spacing: Tailwind-based consistent rhythm system
- Responsive design with mobile-first approach

**State Management:**
- React Query for server state (prayers fetching, mutations)
- Local component state with React hooks
- LocalStorage for persistent user ID generation

**Key Frontend Decisions:**
- Anonymous user system: Users receive a generated "User #XXXX" identifier stored in localStorage
- No authentication required to maintain low barrier to entry
- Prayer cards emphasize readability with serif fonts and generous spacing
- Category filtering without page reloads using React Query
- Toast notifications for user feedback

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js
- TypeScript for type safety
- Drizzle ORM for database interactions
- Neon Database (PostgreSQL-compatible serverless database)
- WebSocket support via `ws` library

**API Design:**
- RESTful API endpoints
- `GET /api/prayers` - Retrieve all prayers or filter by category via query params
- `POST /api/prayers` - Submit new prayer with automatic moderation
- JSON request/response format
- Zod schema validation on all inputs

**Content Moderation:**
- Two-tier AI moderation system using OpenAI APIs
- First pass: OpenAI Moderation API for safety checks
- Second pass: GPT-5 for nuanced prayer content validation
- Moderation criteria: genuine prayer content, positive/hopeful tone, respectful language
- Rejection with specific feedback if content fails moderation

**Key Backend Decisions:**
- Server-side validation using Zod schemas shared with frontend
- Strict content moderation before prayer storage (not post-moderation)
- All prayers marked as "Moderated" to build trust
- Error handling with descriptive messages
- Request logging for API endpoints

### Data Storage

**Database: Neon (PostgreSQL)**
- Serverless PostgreSQL via `@neondatabase/serverless`
- Connection pooling for performance
- WebSocket-based connections

**Schema Design:**
```typescript
prayers table:
- id (varchar, primary key, UUID)
- content (text, not null) - prayer text
- category (varchar(50), not null) - one of 8 predefined categories
- userId (varchar(100), not null) - anonymous user identifier
- createdAt (timestamp, not null) - auto-generated
```

**ORM Choice - Drizzle:**
- Type-safe SQL queries
- Migration support via drizzle-kit
- Schema definition co-located with application code
- Zod integration for runtime validation

**Data Access Patterns:**
- Repository pattern via `DatabaseStorage` class
- All queries ordered by `createdAt DESC` for chronological display
- Category filtering via WHERE clause
- No pagination implemented (assumption: manageable dataset size)

### External Dependencies

**Third-Party Services:**
1. **OpenAI API** (Content Moderation)
   - Moderation API for safety screening
   - GPT-5 Chat Completions for contextual prayer validation
   - Requires `OPENAI_API_KEY` environment variable
   - Critical dependency: Application rejects prayers if API unavailable

2. **Neon Database** (Serverless PostgreSQL)
   - Requires `DATABASE_URL` environment variable
   - Provisioned database mandatory for application startup
   - WebSocket connections for serverless compatibility

**Build & Development Tools:**
- Vite plugins: React, runtime error overlay, Replit-specific plugins (cartographer, dev banner)
- ESBuild for production server bundling
- PostCSS with Tailwind CSS and Autoprefixer
- TypeScript compiler for type checking

**UI Component Dependencies:**
- Radix UI primitives (20+ components imported)
- class-variance-authority for variant management
- clsx and tailwind-merge for className handling
- Lucide React for icons
- date-fns for timestamp formatting
- react-hook-form with Zod resolver for form validation

**Key Dependency Decisions:**
- Shadcn UI approach: Copy component code into project rather than npm package
- Font loading: Google Fonts (Inter, Lora) via CDN in HTML
- No authentication library needed (anonymous-only system)
- Session management: Connect-pg-simple referenced but not implemented (likely future consideration)