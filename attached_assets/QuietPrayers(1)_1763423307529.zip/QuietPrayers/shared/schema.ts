import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const prayers = pgTable("prayers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  userId: varchar("user_id", { length: 100 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPrayerSchema = createInsertSchema(prayers, {
  content: z.string().min(10, "Prayer must be at least 10 characters").max(500, "Prayer must be 500 characters or less"),
  category: z.enum(["Health", "Family", "Gratitude", "Guidance", "Peace", "Strength", "Forgiveness", "Hope"]),
  userId: z.string().min(1),
}).omit({
  id: true,
  createdAt: true,
});

export type InsertPrayer = z.infer<typeof insertPrayerSchema>;
export type Prayer = typeof prayers.$inferSelect;

export const PRAYER_CATEGORIES = [
  "Health",
  "Family", 
  "Gratitude",
  "Guidance",
  "Peace",
  "Strength",
  "Forgiveness",
  "Hope"
] as const;

export type PrayerCategory = typeof PRAYER_CATEGORIES[number];
