import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPrayerSchema } from "@shared/schema";
import { moderateContent } from "./moderation";

export async function registerRoutes(app: Express): Promise<Server> {
  // GET all prayers with optional category filter
  app.get("/api/prayers", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      
      const prayers = category
        ? await storage.getPrayersByCategory(category)
        : await storage.getPrayers();
      
      res.json(prayers);
    } catch (error) {
      console.error("Error fetching prayers:", error);
      res.status(500).json({ message: "Failed to fetch prayers" });
    }
  });

  // POST new prayer with content moderation
  app.post("/api/prayers", async (req, res) => {
    try {
      // Validate request body
      const validationResult = insertPrayerSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({
          message: "Invalid prayer data",
          errors: validationResult.error.errors,
        });
      }

      const prayerData = validationResult.data;

      // Apply strict content moderation
      const moderationResult = await moderateContent(prayerData.content);
      
      if (!moderationResult.allowed) {
        return res.status(400).json({
          message: moderationResult.reason || "Prayer content does not meet community guidelines",
        });
      }

      // Create and store the prayer
      const prayer = await storage.createPrayer(prayerData);
      
      res.status(201).json(prayer);
    } catch (error) {
      console.error("Error creating prayer:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create prayer" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
