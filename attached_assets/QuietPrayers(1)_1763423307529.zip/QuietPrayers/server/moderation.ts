import OpenAI from "openai";

// Using OpenAI's Moderation API and GPT-5 for strict content filtering
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface ModerationResult {
  allowed: boolean;
  reason?: string;
}

export async function moderateContent(content: string): Promise<ModerationResult> {
  // Check if API key is configured - if not, use basic fallback validation
  if (!process.env.OPENAI_API_KEY) {
    console.warn("OPENAI_API_KEY is not configured, using basic validation");
    return basicContentValidation(content);
  }

  try {
    // First pass: Use OpenAI's Moderation API for basic safety checks
    const moderationResponse = await openai.moderations.create({
      input: content,
    });

    const result = moderationResponse.results[0];
    
    // Check if content is flagged by moderation API
    if (result.flagged) {
      const flaggedCategories = Object.entries(result.categories)
        .filter(([_, flagged]) => flagged)
        .map(([category]) => category);
      
      return {
        allowed: false,
        reason: `Content violates community guidelines: ${flaggedCategories.join(", ")}`,
      };
    }

    // Second pass: Use GPT-5 for more nuanced prayer content validation
    const validationResponse = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a content moderator for a prayer-sharing platform. Your job is to ensure that submitted content is:
1. Genuinely a prayer or spiritual reflection
2. Positive, hopeful, or seeking guidance/support
3. Free from spam, advertising, or promotional content
4. Respectful and not targeting any individual or group negatively
5. Not containing requests for money, products, or services
6. Not containing hate speech, violence, or harmful ideologies
7. Written in good faith (not trolling or mocking)

Respond with JSON in this format: { "allowed": true/false, "reason": "explanation if not allowed" }`,
        },
        {
          role: "user",
          content: `Please review this prayer submission: "${content}"`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const validation = JSON.parse(validationResponse.choices[0].message.content || "{}");
    
    if (!validation.allowed) {
      return {
        allowed: false,
        reason: validation.reason || "Content does not meet prayer community standards",
      };
    }

    return { allowed: true };
  } catch (error: any) {
    console.error("Moderation error:", error);
    
    // If rate limited, use fallback validation
    if (error?.status === 429) {
      console.warn("OpenAI rate limit reached, using basic validation fallback");
      return basicContentValidation(content);
    }
    
    // For other errors, also fall back to basic validation
    console.warn("OpenAI error, using basic validation fallback");
    return basicContentValidation(content);
  }
}

// Basic fallback validation when OpenAI is unavailable
function basicContentValidation(content: string): ModerationResult {
  const lowerContent = content.toLowerCase();
  
  // Block obvious spam patterns
  const spamPatterns = [
    /buy now/i,
    /click here/i,
    /limited time/i,
    /\$\d+/,
    /https?:\/\//,
    /www\./,
    /viagra/i,
    /casino/i,
    /lottery/i,
  ];
  
  for (const pattern of spamPatterns) {
    if (pattern.test(content)) {
      return {
        allowed: false,
        reason: "Content appears to contain promotional or spam material",
      };
    }
  }
  
  // Block hate speech indicators (basic list)
  const hateWords = ['hate', 'kill', 'die', 'death to'];
  const containsHate = hateWords.some(word => lowerContent.includes(word));
  
  if (containsHate) {
    return {
      allowed: false,
      reason: "Content may contain inappropriate language",
    };
  }
  
  // Allow if passes basic checks
  return { allowed: true };
}
