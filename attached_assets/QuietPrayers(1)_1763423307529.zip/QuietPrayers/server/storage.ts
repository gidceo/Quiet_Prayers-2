import { prayers, type Prayer, type InsertPrayer } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createPrayer(prayer: InsertPrayer): Promise<Prayer>;
  getPrayers(): Promise<Prayer[]>;
  getPrayersByCategory(category: string): Promise<Prayer[]>;
}

export class DatabaseStorage implements IStorage {
  async createPrayer(insertPrayer: InsertPrayer): Promise<Prayer> {
    const [prayer] = await db
      .insert(prayers)
      .values(insertPrayer)
      .returning();
    return prayer;
  }

  async getPrayers(): Promise<Prayer[]> {
    return await db
      .select()
      .from(prayers)
      .orderBy(desc(prayers.createdAt));
  }

  async getPrayersByCategory(category: string): Promise<Prayer[]> {
    return await db
      .select()
      .from(prayers)
      .where(eq(prayers.category, category))
      .orderBy(desc(prayers.createdAt));
  }
}

export const storage = new DatabaseStorage();
